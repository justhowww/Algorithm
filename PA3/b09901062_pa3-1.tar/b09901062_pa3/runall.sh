for i in 1 2 3 4 7 8
do 
    ./bin/cb ./inputs/public_case_$i.in ./outputs/public_case_$i.out
done